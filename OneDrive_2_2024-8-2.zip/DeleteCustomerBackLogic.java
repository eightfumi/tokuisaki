/**
 * DeleteCustomerBackLogic.java
 *
 * All Rights Reserved, Copyright(c) Fujitsu Learning Media Limited
 */

package jsys.sales.logic;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import jsys.sales.common.SalesBusinessException;
import jsys.sales.common.SalesSystemException;
import jsys.sales.dao.ConnectionManager;
import jsys.sales.dao.CustomerDAO;
import jsys.sales.entity.Customer;

/**
 *
 * @author FLM
 * @version 1.0.0
 */
public class DeleteCustomerBackLogic {
	public ArrayList<Customer> deleteCustomerBack(String custCode) throws SalesBusinessException, SalesSystemException {
		System.out.println("DeleteCustomerBackLogic進行開始");
		Connection con = null;
		boolean result = false;
		ArrayList<Customer> deleteCustomerList = null;

		try {
			// データベースの接続を取得する
			con = ConnectionManager.getConnection();

			// 得意先テーブルアクセス用のDAOを生成し、メソッドを呼び出す。
			CustomerDAO customerDAO = new CustomerDAO(con);
			result = customerDAO.backCustomer(custCode);

			// 削除に失敗した場合、エラーを発生させる。
			if (result == false) {
				throw new SalesBusinessException("得意先の復元に失敗しました。");
			}

			deleteCustomerList = customerDAO.findAlldeleteCustomer();

		} catch (SQLException e) {
				e.printStackTrace();
				throw new SalesSystemException("システムエラーが発生しました。システム管理者に連絡してください。");
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new SalesSystemException("システムエラーが発生しました。システム管理者に連絡してください。");
			}
		}
		return deleteCustomerList;
	}
}