/**
 * Password.java
 *
 * All Rights Reserved, Copyright(c) Fujitsu Learning Media Limited
 */

package jsys.sales.entity;

/**
 *
 * @author FLM
 * @version 1.0.0
 */
public class Administrator {


	private String admin_password;


	/**
	 * コンストラクタ（引数なし）
	 */
	public Administrator() {
	}


	public Administrator(String admin_password) {
		this.admin_password = admin_password;
	}


	/**
	 * admin_passwordのGetter
	 * @return admin_password
	 */
	public String getAdmin_password() {
		return admin_password;
	}


	/**
	 * admin_passwordのSetter
	 * @param admin_password
	 */
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}

}