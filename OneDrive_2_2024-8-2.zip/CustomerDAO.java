package jsys.sales.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jsys.sales.entity.Customer;

public class CustomerDAO {

	// データベースの接続
	private Connection con;

	// コンストラクタ
	public CustomerDAO(Connection con) {
		this.con = con;
	}

	// 得意先を検索する
	public Customer findCustomer(String custCode) throws SQLException {
		String sql = "SELECT customer_code, customer_name, customer_telno,"
				+ "customer_postalcode, customer_address, discount_rate "
				+ "FROM customer WHERE customer_code = ? and delete_flag = false";
		PreparedStatement stmt = null;
		ResultSet res = null;
		Customer customer = null;

		try {
			stmt = con.prepareStatement(sql);
			stmt.setString(1, custCode);
			res = stmt.executeQuery();

			if (res.next()) {
				customer = new Customer(res.getString("customer_code"),
						res.getString("customer_name"),
						res.getString("customer_telno"),
						res.getString("customer_postalcode"),
						res.getString("customer_address"),
						res.getInt("discount_rate"));
			}
		} finally {
			if (res != null) {
				res.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return customer;
	}

	// 得意先を登録する
	public Customer registCustomer(Customer customer) throws SQLException {
		String sql = "INSERT INTO customer VALUES(?,?,?,?,?,?,false)";
		PreparedStatement stmt = null;

		try {
			// PreparedStatementの作成
			stmt = con.prepareStatement(sql);
			// パラメータの設定
			stmt.setString(1, customer.getCustCode());
			stmt.setString(2, customer.getCustName());
			stmt.setString(3, customer.getTelNo());
			stmt.setString(4, customer.getPostalCode());
			stmt.setString(5, customer.getAddress());
			stmt.setInt(6, customer.getDiscountRate());

			// SQL文の実行
			stmt.executeUpdate();

		} finally {
			// クローズ処理
			if (stmt != null) {
				stmt.close();
			}
		}
		return customer;
	}

	// delete_flagを使用して得意先を削除する
	public boolean deleteCustomer(Customer customer) throws SQLException {
		String sql = "UPDATE customer SET delete_flag = 1 WHERE customer_code = ?";
		PreparedStatement stmt = null;
		boolean result = false;

		try {
			// PreparedStatementの作成
			stmt = con.prepareStatement(sql);
			// パラメータの設定
			stmt.setString(1, customer.getCustCode());
			// SQL文の実行
			int count = stmt.executeUpdate();
			if (count == 1) {
				result = true;
			}
		} finally {
			// クローズ処理
			if (stmt != null) {
				stmt.close();
			}
		}
		return result;
	}

	// 得意先を更新する
	public boolean updateCustomer(Customer customer) throws SQLException {
		String sql = "UPDATE customer SET customer_name=?, customer_telno=?, "
				+ "customer_postalcode=?, customer_address=?, discount_rate=? "
				+ "WHERE customer_code = ? and delete_flag = 0";
		PreparedStatement stmt = null;
		boolean result = false;

		try {
			// PreparedStatementの作成
			stmt = con.prepareStatement(sql);
			// パラメータの設定
			stmt.setString(1, customer.getCustName());
			stmt.setString(2, customer.getTelNo());
			stmt.setString(3, customer.getPostalCode());
			stmt.setString(4, customer.getAddress());
			stmt.setInt(5, customer.getDiscountRate());
			stmt.setString(6, customer.getCustCode());

			// SQL文の実行
			int count = stmt.executeUpdate();
			if (count == 1) {
				result = true;
			}
		} finally {
			// クローズ処理
			if (stmt != null) {
				stmt.close();
			}
		}
		return result;
	}

	// 得意先を全件検索する
	public ArrayList<Customer> findAllCustomer() throws SQLException {
		String sql = "SELECT customer_code, customer_name, customer_telno, "
				+ "customer_postalcode, customer_address, discount_rate "
				+ "FROM customer where delete_flag = 0";
		PreparedStatement stmt = null;
		ResultSet res = null;
		ArrayList<Customer> customerList = new ArrayList<>();

		try {
			// PreparedStatementの作成
			stmt = con.prepareStatement(sql);
			// SQL文の実行
			res = stmt.executeQuery();

			// 結果セットから情報を取り出す
			Customer customer = null;
			while (res.next()) {
				customer = new Customer(res.getString("customer_code"),
						res.getString("customer_name"),
						res.getString("customer_telno"),
						res.getString("customer_postalcode"),
						res.getString("customer_address"),
						res.getInt("discount_rate"));
				customerList.add(customer);
			}
		} finally {
			// クローズ処理
			if (res != null) {
				res.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return customerList;
	}

	// 削除済み得意先を全件検索する
		public ArrayList<Customer> findAlldeleteCustomer() throws SQLException {
			String sql = "SELECT customer_code, customer_name, customer_telno, customer_postalcode, customer_address, discount_rate "
					+ "FROM customer where delete_flag = 1";
			PreparedStatement stmt = null;
			ResultSet res = null;
			ArrayList<Customer> deleteCustomerList = new ArrayList<>();

			try {
				// PreparedStatementの作成
				stmt = con.prepareStatement(sql);
				// SQL文の実行
				res = stmt.executeQuery();

				// 結果セットから情報を取り出す
				Customer customer = null;
				while (res.next()) {
					customer = new Customer(res.getString("customer_code"),
							res.getString("customer_name"),
							res.getString("customer_telno"),
							res.getString("customer_postalcode"),
							res.getString("customer_address"),
							res.getInt("discount_rate"));
					deleteCustomerList.add(customer);
				}
			} finally {
				// クローズ処理
				if (res != null) {
					res.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			}
			return deleteCustomerList;
		}
		//削除済み得意先を復元する
		public boolean backCustomer(String custCode) throws SQLException {
			String sql =
			"UPDATE customer SET delete_flag = 0 WHERE customer_code = ?";


			PreparedStatement stmt = null;
			boolean result = false;

			try {
				// PreparedStatementの作成
				stmt = con.prepareStatement(sql);
				// パラメータの設定

				stmt.setString(1, custCode);

				// SQL文の実行
				int count = stmt.executeUpdate();

				if (count == 1) {
					result = true;
				}
			} finally {
				// クローズ処理
				if (stmt != null) {
					stmt.close();
				}
			}
			return result;
		}


}
