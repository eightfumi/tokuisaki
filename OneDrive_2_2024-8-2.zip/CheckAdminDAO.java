/**
 * CheckAdminDAO.java
 *
 * All Rights Reserved, Copyright(c) Fujitsu Learning Media Limited
 */

package jsys.sales.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jsys.sales.entity.Administrator;

/**
 *
 * @author FLM
 * @version 1.0.0
 */
public class CheckAdminDAO {
	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param con
	 *            データベースの接続オブジェクト
	 */
	public CheckAdminDAO(Connection con) {
		this.con = con;
	}


	public String checkAdmin(String admin_password) throws SQLException {
		String sql = "SELECT admin_password FROM password WHERE admin_password = ?";
		PreparedStatement stmt = null;
		ResultSet res = null;
		String administrator =null;
		//boolean result = false;

		try {
			// PreparedStatementの作成
			stmt = con.prepareStatement(sql);
			// パラメータの設定
			stmt.setString(1, admin_password);

			// SQL文の実行
			res = stmt.executeQuery();

			// 結果セットの確認
			if (res.next()) {
				administrator = res.getString("admin_password");
			}

		} finally {
			// クローズ処理
			if (res != null) {
				res.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return administrator;
	}
}
