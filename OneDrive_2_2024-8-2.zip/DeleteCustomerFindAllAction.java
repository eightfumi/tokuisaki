/**
 * DeleteCustomerFindAll.java
 *
 * All Rights Reserved, Copyright(c) Fujitsu Learning Media Limited
 */

package jsys.sales.web;

import java.util.ArrayList;

import jakarta.servlet.http.HttpServletRequest;
import jsys.sales.common.SalesBusinessException;
import jsys.sales.common.SalesSystemException;
import jsys.sales.entity.Customer;
import jsys.sales.logic.DeleteCustomerFindAllLogic;

/**
 *
 * @author FLM
 * @version 1.0.0
 */
public class DeleteCustomerFindAllAction implements ActionIF {
	@Override
	public String execute(HttpServletRequest request) {
		System.out.println("DeleteCustomerFindAllAction進行開始");
		String page = "deleteCustomerFindAllResultView.jsp";

		try {

			//業務ロジックの呼び出し
			DeleteCustomerFindAllLogic logic = new DeleteCustomerFindAllLogic();
			ArrayList <Customer> deletecustomerList = logic.findAlldeleteCustomer();

			//処理結果の格納
			request.setAttribute("deleteCustomerList", deletecustomerList);

		} catch (SalesBusinessException e) {
			request.setAttribute("errorMessage", e.getMessage());
			request.setAttribute("errorMessageList", e.getMessageList());

		} catch (SalesSystemException e) {
			request.setAttribute("errorMessage", e.getMessage());
			e.printStackTrace();
		}
		System.out.println("DeleteCustomerFindAllAction退散");
		return page;
	}
}
