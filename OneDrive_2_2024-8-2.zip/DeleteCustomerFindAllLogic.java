/**
 * DeleteCustomerFindAllLogic.java
 *
 * All Rights Reserved, Copyright(c) Fujitsu Learning Media Limited
 */

package jsys.sales.logic;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import jsys.sales.common.SalesBusinessException;
import jsys.sales.common.SalesSystemException;
import jsys.sales.dao.ConnectionManager;
import jsys.sales.dao.CustomerDAO;
import jsys.sales.entity.Customer;

/**
 *
 * @author FLM
 * @version 1.0.0
 */
public class DeleteCustomerFindAllLogic {
	public ArrayList<Customer> findAlldeleteCustomer()
			throws SalesBusinessException, SalesSystemException {
		System.out.println("DeleteCustomerFindAllLogic進行開始");
		Connection con = null;
		ArrayList<Customer> deleteCustomerList = null;

		try {
			//データベースの接続を取得する
			con = ConnectionManager.getConnection();

			//DAOを生成し、目そ度を呼び出す
			CustomerDAO customerDAO = new CustomerDAO(con);
			deleteCustomerList = customerDAO.findAlldeleteCustomer();

			//検索結果がない場合、業務エラーを発生させる
			if (deleteCustomerList.isEmpty()) {
				throw new SalesBusinessException("削除済みの得意先一覧が存在しません。");
			}
		} catch (SQLException e) {
			//データベースエラーの場合、システムエラーを発生させる
			throw new SalesSystemException("システムエラーが発生しました。管理者に連絡してください。");
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				throw new SalesSystemException("システムエラーが発生しました。管理者に連絡してください。");
			}
		}
		System.out.println("DeleteCustomerFindAllLogic退散");
		return deleteCustomerList;
	}
}
