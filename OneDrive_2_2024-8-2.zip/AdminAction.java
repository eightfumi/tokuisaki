/**
 * AdminAction.java
 *
 * All Rights Reserved, Copyright(c) Fujitsu Learning Media Limited
 */

package jsys.sales.web;

import java.util.ArrayList;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jsys.sales.common.SalesBusinessException;
import jsys.sales.common.SalesSystemException;
import jsys.sales.logic.AdminLogic;

/**
 *
 * @author FLM
 * @version 1.0.0
 */
public class AdminAction implements ActionIF{

	@Override
	public String execute(HttpServletRequest request) {
		System.out.println("AdminAction進行開始");
		String page = "ManagerMainMenu.jsp";
		try {

			// パラメータの取得
			String admin_password = request.getParameter("admin_password");

			// エラーメッセージリストの生成
			ArrayList<String> errorMessageList = new ArrayList<>();
			if (errorMessageList == null || errorMessageList.equals("")) {
				errorMessageList.add("パスワードが未入力です。");
			}
			if (!errorMessageList.isEmpty()) {
				throw new SalesBusinessException(errorMessageList);
			}
			AdminLogic logic = new AdminLogic();
			String administrator = logic.checkAdmin(admin_password);
			HttpSession session = request.getSession(true);
			session.setAttribute("administrator", administrator);

		} catch (SalesBusinessException e) {
			request.setAttribute("errorMessage", e.getMessage());
			request.setAttribute("errorMessageList", e.getMessageList());
			page = "ManagerView.jsp";

		} catch (SalesSystemException e) {
			request.setAttribute("errorMessage", e.getMessage());
			page = "SystemErrorPage.jsp";

		}
		System.out.println("AdminActions退散");
		return page;
	}
}
